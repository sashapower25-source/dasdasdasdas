npm i &&
pm2 restart TODServer